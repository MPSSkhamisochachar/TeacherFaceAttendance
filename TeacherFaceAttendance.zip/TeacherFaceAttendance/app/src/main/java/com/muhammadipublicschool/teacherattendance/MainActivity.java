package com.muhammadipublicschool.teacherattendance;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    // Teacher-facing Face Attendance page (default route - no ?action=admin)
    private static final String URL =
        "https://script.google.com/macros/s/AKfycbxdR-pMtXymX5kKe2lRHUWYYloj3dLjP9gsLNbdKnFWhwvX6qx7MX2mTbi0FkP6X6qToA/exec";

    private static final int FILE_CHOOSER_REQUEST_CODE = 5174;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri capturedPhotoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);
        configureWebView();

        if (savedInstanceState == null) {
            webView.loadUrl(URL);
        } else {
            webView.restoreState(savedInstanceState);
        }

        // Camera + Location permission app khulte hi maang lein
        ActivityCompat.requestPermissions(this, new String[]{
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        }, 1001);
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setGeolocationEnabled(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false; // navigation app ke andar hi rakhein
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                filePathCallback = callback;
                return launchCameraCapture();
            }

            // NAYA: webpage jab GPS location maange, seedha allow kar dein
            // (Android system permission already upar mangi ja chuki hai)
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }
        });
    }

    private boolean launchCameraCapture() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (takePictureIntent.resolveActivity(getPackageManager()) == null) {
            failFileChooser();
            return false;
        }

        File photoFile;
        try {
            photoFile = createImageFile();
        } catch (IOException e) {
            failFileChooser();
            return false;
        }

        capturedPhotoUri = FileProvider.getUriForFile(
            this,
            getPackageName() + ".fileprovider",
            photoFile
        );

        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, capturedPhotoUri);
        takePictureIntent.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        );

        startActivityForResult(takePictureIntent, FILE_CHOOSER_REQUEST_CODE);
        return true;
    }

    private void failFileChooser() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (storageDir != null && !storageDir.exists()) {
            storageDir.mkdirs();
        }
        return File.createTempFile("face_" + timeStamp, ".jpg", storageDir);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) {
                return;
            }
            if (resultCode == RESULT_OK && capturedPhotoUri != null) {
                filePathCallback.onReceiveValue(new Uri[]{capturedPhotoUri});
            } else {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }
}
