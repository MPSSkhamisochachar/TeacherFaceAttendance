# Teacher Face Attendance — Android App

Teachers ke liye alag app (`com.muhammadipublicschool.teacherattendance`).
Same Apps Script deployment ka default page (Face Attendance - Time In/Out)
load karti hai.

## Fixes included
- **Camera fix**: `MainActivity.java` mein WebView ka `onShowFileChooser`
  khaas tarah likha gaya hai taake "Scan My Face" dabate hi seedha camera
  khule - generic file-picker nahi. FileProvider set hai
  (`AndroidManifest.xml` + `res/xml/file_paths.xml`).
- **GPS fix**: `onGeolocationPermissionsShowPrompt` override kiya hai taake
  webpage ki location request WebView ke andar khud allow ho jaye (warna
  GPS check hamesha fail hota).

## Build
Zip GitHub repo mein upload karein (ya files individually), Actions →
"Build Android APK" run karein. APK "Teacher-Face-Attendance-APK" artifact
mein milega.
